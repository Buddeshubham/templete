import React from "react";

interface Props {
  children: React.ReactNode;
}

const MainLayout: React.FC<Props> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-blue-600 text-white p-4">My App</header>
      <main className="flex-1">{children}</main>
      <footer className="bg-gray-800 text-white p-4 text-center">
        © 2025 My App
      </footer>
    </div>
  );
};

export default MainLayout;
