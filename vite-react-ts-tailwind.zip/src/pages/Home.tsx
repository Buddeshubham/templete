import React from "react";

const Home: React.FC = () => {
  return (
    <div className="text-center p-6">
      <h1 className="text-3xl font-bold text-blue-600">
        🚀 Vite + React + TypeScript + Tailwind
      </h1>
      <p className="mt-2 text-gray-600">Your project is ready!</p>
    </div>
  );
};

export default Home;
