export default function App() {
  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-r from-blue-500 to-purple-600">
      <h1 className="text-4xl font-bold text-white">
        🚀 Vite + React + TailwindCSS Ready!
      </h1>
    </div>
  )
}
